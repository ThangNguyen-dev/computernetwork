<!--MAIN-->
<main id="main">

    <?php require_once "mvc/views/{$data['page']}.php" ?>
    <!--       END ARTICLES LIST-->

    <!--   RECENT ARTICLE -->
    <div class="right-siderbar-sticky">
        <h3><a href="https://www.computernetworkingnotes.com/networking-tutorials/">Networking Tutorials</a></h3>
        <ul class="ul-arrow">
            <li>
                <a href="https://www.computernetworkingnotes.com/networking-tutorials/data-modulation-in-computer-networks.html">Data
                    Modulation in Computer Networks
                </a>
            </li>
        </ul>
    </div>

</main>