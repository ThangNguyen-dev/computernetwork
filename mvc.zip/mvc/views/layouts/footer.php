<footer id="footer">
    <div id="navbar-bottom-menu" class="d-flex justify-content-center">
        <nav id="bottom-menu">
            <ul>
                <li><a href="#">About</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Tern and Conditions</a></li>
            </ul>
        </nav>
    </div>
    <p style="text-align: center">Computer Networking Notes and Study Guides © 2021. All Rights Reserved.</p>
</footer>