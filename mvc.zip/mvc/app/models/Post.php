<?php

namespace app\models;

use app\core\Model;

class Post extends Model
{
}
